// Alternância entre tema claro e escuro
function toggleTheme() { document.body.classList.toggle('dark'); }